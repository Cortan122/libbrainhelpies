#pragma once

#include <stdbool.h>
#include <stdint.h>

#pragma directory("https://github.com/nothings/stb")
#include "stb_ds.h"

typedef enum VFSType {
  VFS_NONE,
  // VFS_FILE,
  VFS_ZIP,
  // VFS_GIT,
  // VFS_NEOCITIES,
} VFSType;

typedef struct VFSFile {
  struct VFS* system;
  bool is_valid;
  char* path;
  time_t date;

  bool mem_valid;
  void* mem_buffer;
  size_t mem_length;

  bool disk_valid;
  char* disk_path;

} VFSFile;

typedef struct VFS {
  VFSType type;
  bool can_read;
  bool can_write;
  char* uri;
  VFSFile* files;

  void* opaque;
} VFS;

VFS* VFS_create(char* uri, VFSType type);
void VFS_delete(VFS* vfs);

int VFS_findFiles(VFS* vfs, char* path);
int VFS_commitRead(VFS* vfs);

int VFS_writeFile(VFS* vfs, char* file, void* buffer, size_t length);
int VFS_commitWrite(VFS* vfs);

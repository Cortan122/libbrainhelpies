#include "VFS.h"
#include "diagnostic.h"

VFS* VFS_create(char* uri, VFSType type){
  UNIMPLEMENTED();
}

void VFS_delete(VFS* vfs){
  UNIMPLEMENTED();
}

int VFS_findFiles(VFS* vfs, char* path){
  UNIMPLEMENTED();
}

int VFS_commitRead(VFS* vfs){
  UNIMPLEMENTED();
}

int VFS_writeFile(VFS* vfs, char* file, void* buffer, size_t length){
  UNIMPLEMENTED();
}

int VFS_commitWrite(VFS* vfs){
  UNIMPLEMENTED();
}

#include <stdio.h>

#include "diagnostic.h"

int main(){
  printf(INFO"hello world\n");

  timer("10m loops");
  for(int i = 0; i < 10000000; i++){
    // do nothing!!
  }
  timer(NULL);

  char* filename = "not a real file";
  FILE* f = fopen(filename, "r");
  if(f == NULL){
    PERROR("couldn't open file '%s'", filename);
  }else{
    fclose(f);
  }

  UNREACHABLE();
  UNIMPLEMENTED();

  // SEGFAULT();
  return 0;
}
